import { useState } from "react";
import { DailyData } from "../types";
import { clsx } from "clsx";
import { ChevronDown, ChevronUp, TrendingDown, TrendingUp, History, FileText } from "lucide-react";
import { isBefore, startOfToday, parse } from "date-fns";
import { formatCurrency as centralizedFormatCurrency, formatDate as centralizedFormatDate } from "../utils/formatters";

interface Props {
  data: DailyData[];
  isMaximized?: boolean;
  currency?: string;
  dateFormat?: string;
}

export default function ReconciliationTable({ 
  data, 
  isMaximized = false,
  currency = 'USD',
  dateFormat = 'MM/DD/YYYY'
}: Props) {
  const [isCollapsed, setIsCollapsed] = useState(!isMaximized);

  const formatCurrency = (val: number) => centralizedFormatCurrency(val, currency, true);
  const formatDate = (date: string | Date) => centralizedFormatDate(date, dateFormat);

  // Only show historical data or days with actuals
  const historicalData = data.filter(row => {
    const dayDate = parse(row.date, "M/d/yyyy", new Date());
    return isBefore(dayDate, startOfToday()) || row.actualCashIn !== undefined || row.actualCashOut !== undefined;
  }).reverse(); // Show most recent first

  const totals = historicalData.reduce((acc, curr) => ({
    projIn: acc.projIn + curr.cashIn,
    actIn: acc.actIn + (curr.actualCashIn || 0),
    projOut: acc.projOut + curr.cashOut,
    actOut: acc.actOut + (curr.actualCashOut || 0),
  }), { projIn: 0, actIn: 0, projOut: 0, actOut: 0 });

  if (historicalData.length === 0) {
    return (
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-12 text-center">
        <div className="max-w-xs mx-auto">
          <div className="w-12 h-12 bg-slate-50 dark:bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4">
            <FileText className="w-6 h-6 text-slate-400 dark:text-slate-500" />
          </div>
          <h3 className="text-sm font-semibold text-slate-900 dark:text-white mb-1">No Actuals Found</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-6">
            Upload your bank feed data in the Reports tab to see historical reconciliation and variance analysis.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden ${isMaximized ? 'border-none shadow-none' : ''}`}>
      <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/20">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-100 dark:bg-indigo-900/30 rounded-lg text-indigo-600 dark:text-indigo-400">
            <History className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-slate-900 dark:text-white">Historical Reconciliation</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">Actual bank activity vs. original projections</p>
          </div>
        </div>
        {!isMaximized && (
          <button 
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="flex items-center gap-2 px-3 py-1.5 text-xs font-bold text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg transition-all"
          >
            {isCollapsed ? (
              <>
                <ChevronDown className="w-4 h-4" />
                View History
              </>
            ) : (
              <>
                <ChevronUp className="w-4 h-4" />
                Hide History
              </>
            )}
          </button>
        )}
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50 dark:bg-slate-800/50 border-y border-slate-200 dark:border-slate-800">
              <th className="px-4 py-3 text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Date</th>
              <th className="px-4 py-3 text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider text-right">Projected In</th>
              <th className="px-4 py-3 text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider text-right">Actual In</th>
              <th className="px-4 py-3 text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider text-right">Variance</th>
              <th className="px-4 py-3 text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider text-right">Projected Out</th>
              <th className="px-4 py-3 text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider text-right">Actual Out</th>
              <th className="px-4 py-3 text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider text-right">Variance</th>
            </tr>
          </thead>
          {!isCollapsed && (
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {historicalData.map((row, idx) => {
                const inVariance = row.actualCashIn !== undefined ? row.actualCashIn - row.cashIn : 0;
                const outVariance = row.actualCashOut !== undefined ? row.actualCashOut - row.cashOut : 0;
                const hasActuals = row.actualCashIn !== undefined || row.actualCashOut !== undefined;

                return (
                  <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                    <td className="px-4 py-4 text-sm font-medium text-slate-700 dark:text-slate-300">{formatDate(row.date)}</td>
                    <td className="px-4 py-4 text-sm text-slate-500 dark:text-slate-400 text-right">{formatCurrency(row.cashIn)}</td>
                    <td className="px-4 py-4 text-sm text-emerald-600 dark:text-emerald-400 font-medium text-right">
                      {row.actualCashIn !== undefined ? formatCurrency(row.actualCashIn) : "—"}
                    </td>
                    <td className={clsx(
                      "px-4 py-4 text-[10px] font-bold text-right",
                      inVariance > 0 ? "text-emerald-600 dark:text-emerald-400" : inVariance < 0 ? "text-rose-600 dark:text-rose-400" : "text-slate-400 dark:text-slate-600"
                    )}>
                      {row.actualCashIn !== undefined && (
                        <div className="flex items-center justify-end gap-1">
                          {inVariance > 0 ? <TrendingUp className="w-3 h-3" /> : inVariance < 0 ? <TrendingDown className="w-3 h-3" /> : null}
                          {formatCurrency(inVariance)}
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-4 text-sm text-slate-500 dark:text-slate-400 text-right">{formatCurrency(row.cashOut)}</td>
                    <td className="px-4 py-4 text-sm text-rose-600 dark:text-rose-400 font-medium text-right">
                      {row.actualCashOut !== undefined ? formatCurrency(row.actualCashOut) : "—"}
                    </td>
                    <td className={clsx(
                      "px-4 py-4 text-[10px] font-bold text-right",
                      outVariance < 0 ? "text-emerald-600 dark:text-emerald-400" : outVariance > 0 ? "text-rose-600 dark:text-rose-400" : "text-slate-400 dark:text-slate-600"
                    )}>
                      {row.actualCashOut !== undefined && (
                        <div className="flex items-center justify-end gap-1">
                          {outVariance < 0 ? <TrendingUp className="w-3 h-3" /> : outVariance > 0 ? <TrendingDown className="w-3 h-3" /> : null}
                          {formatCurrency(Math.abs(outVariance))}
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          )}
          <tfoot className="bg-slate-50 dark:bg-slate-800/50 border-t border-slate-200 dark:border-slate-800">
            <tr>
              <td className="px-4 py-4 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Historical Totals</td>
              <td className="px-4 py-4 text-xs font-medium text-slate-500 dark:text-slate-400 text-right">{formatCurrency(totals.projIn)}</td>
              <td className="px-4 py-4 text-sm font-bold text-emerald-700 dark:text-emerald-400 text-right">{formatCurrency(totals.actIn)}</td>
              <td className="px-4 py-4 text-right"></td>
              <td className="px-4 py-4 text-xs font-medium text-slate-500 dark:text-slate-400 text-right">{formatCurrency(totals.projOut)}</td>
              <td className="px-4 py-4 text-sm font-bold text-rose-700 dark:text-rose-400 text-right">{formatCurrency(totals.actOut)}</td>
              <td className="px-4 py-4 text-right"></td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
}
